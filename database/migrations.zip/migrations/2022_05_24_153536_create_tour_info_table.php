<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTourInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tour_info', function (Blueprint $table) {
            $table->id();
            $table->integer('seo_id');         // [ref: > seo.id]
            $table->integer('location_id');     /* tour ở đâu */
            $table->integer('departure_id');    /* tour khởi hành từ đâu */
            $table->string('code', 20);
            $table->text('name');
            $table->integer('price_show');
            $table->integer('price_del')->nullable();
            $table->integer('days');
            $table->integer('nights');
            $table->string('pick_up', 255)->nullable();
            $table->string('staff_name', 255)->nullable();
            $table->string('staff_phone', 15)->nullable();
            $table->text('staff_email')->nullable();
            $table->boolean('status_show')->default(1);
            $table->boolean('status_sidebar')->default(1);
            $table->text('note')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Schema::dropIfExists('tour_info');
    }
}

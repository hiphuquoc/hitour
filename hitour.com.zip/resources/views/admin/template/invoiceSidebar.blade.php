<div class="invoiceBoxSidebar">
    <div class="invoiceBoxSidebar_title">
        Tóm tắt Booking
    </div>
    <div class="invoiceBoxSidebar_content">
        <div class="invoiceBoxSidebar_content_item">
            Tour Vũng Tàu Côn Đảo 3 ngày 2 đêm
        </div>
        <div class="invoiceBoxSidebar_content_item">
            Resort 3*
        </div>
        <div class="invoiceBoxSidebar_content_item">
            27-08-2022
        </div>
        <div class="invoiceBoxSidebar_content_item columnBox">
            <div class="oneLine columnBox_item">
                <div class="columnBox_item_column">
                    <div>Người lớn</div>
                    <div>3 * 2,250,000đ</div>
                </div>
                <div class="columnBox_item_column" style="width:160px;">
                    <div>-</div>
                    <div>8,750,000đ</div>
                </div>
            </div>
            <div class="oneLine columnBox_item">
                <div class="columnBox_item_column">
                    <div>Người lớn</div>
                    <div>3 * 2,250,000đ</div>
                </div>
                <div class="columnBox_item_column" style="width:160px;">
                    <div>-</div>
                    <div>8,750,000đ</div>
                </div>
            </div>
            <div class="oneLine columnBox_item" style="padding-top:0.5rem;margin-top:0.5rem;border-top:1px dashed #d1d1d1;">
                <div class="columnBox_item_column">
                    Tổng
                </div>
                <div class="columnBox_item_column" style="width:160px;">
                    8,750,000đ
                </div>
            </div>
        </div>
    </div>
</div>